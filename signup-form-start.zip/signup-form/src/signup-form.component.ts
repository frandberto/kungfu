import { Component } from '@angular/core';

@Component({
  selector: 'signup-form',
  template: `
    To do...
  `
})
export class SignupFormComponent {

}
